package com.example.foc;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class activityHome extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //loading the default fragment
        loadFragment(new homeFragment());

        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.bottom_nav_view);
        navigation.setOnNavigationItemSelectedListener(this);

     //   Toast.makeText(this,"FoodonCampus started",Toast.LENGTH_LONG).show();

    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        Fragment fragment = null;

        switch (item.getItemId()) {
            case R.id.tabHome:
                fragment = new homeFragment();
                break;

            case R.id.tabCuisine:
                fragment = new searchFragment();
                break;

            case R.id.tabOrders:
                fragment = new ordersFragment();
                break;

            case R.id.tabProfile:
                fragment = new profileFragment();
                break;
        }

        return loadFragment(fragment);
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }



//    @Override
//    public void onPause() {
//        super.onPause();
//
//        Toast.makeText(this,"FoodonCampus paused",Toast.LENGTH_LONG).show();
//
//
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//
//        Toast.makeText(this,"FoodonCampus resumed",Toast.LENGTH_LONG).show();
//
//    }





}
