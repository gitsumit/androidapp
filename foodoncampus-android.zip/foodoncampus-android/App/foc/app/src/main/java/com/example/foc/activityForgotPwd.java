package com.example.foc;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activityForgotPwd extends AppCompatActivity implements View.OnClickListener {

    EditText objEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pwd);

        objEmail   = (EditText)findViewById(R.id.txtResetEmail);


        Button btn = (Button) findViewById(R.id.button_reset);
        btn.setOnClickListener(this);
    }

    public void doSignIn(View v)
    {
        Intent objIntent = new Intent(this, activitySignIn.class);
        startActivity(objIntent);
    }

    @Override
    public void onClick(View v)
    {

        if (objEmail.getText().toString().trim().equals(""))
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Failure! Please type your email.");

            builder.setPositiveButton("OK", null);
            AlertDialog dialog = builder.create();
            dialog.show();

            Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveBtn.setTextColor(Color.parseColor("#E91E63"));

        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Password reset link has been sent to registered e-mail.");

            builder.setPositiveButton("OK", null);
            AlertDialog dialog = builder.create();
            dialog.show();

            Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveBtn.setTextColor(Color.parseColor("#E91E63"));

        }



    }
}
