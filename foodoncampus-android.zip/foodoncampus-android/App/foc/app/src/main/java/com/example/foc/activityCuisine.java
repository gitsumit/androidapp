package com.example.foc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class activityCuisine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuisine);
    }
}
