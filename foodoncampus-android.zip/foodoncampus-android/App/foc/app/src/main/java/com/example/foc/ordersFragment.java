package com.example.foc;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

public class ordersFragment extends Fragment {

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //just change the fragment_dashboard
        //with the fragment you want to inflate
        //like if the class is HomeFragment it should have R.layout.home_fragment
        //if it is DashboardFragment it should have R.layout.fragment_dashboard


        View view =  inflater.inflate(R.layout.orders_fragment_layout, null);

        ImageView onClick = (ImageView) view.findViewById(R.id.order1);

        onClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                builder.setTitle("Order Summary");
                builder.setMessage("Order Date & Items & Payment");


                builder.setPositiveButton("OK", null);
                AlertDialog dialog = builder.create();
                dialog.show();

                dialog.getWindow().setLayout(1200,1500);

//                Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
//                positiveBtn.setTextColor(Color.parseColor("#E91E63"));
            }
        });

        return  view;

    }

}
