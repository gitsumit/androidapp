package com.example.foc;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class profileFragment extends Fragment implements View.OnClickListener {


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.profile_fragment_layout, null);


        Button btn = (Button) v.findViewById(R.id.button_signout);
        btn.setOnClickListener(this);


        Button btn1 = (Button) v.findViewById(R.id.button_update);
        btn1.setOnClickListener(this);


        return v;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId())
        {


            case R.id.button_update:

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                        getActivity());
                alertDialog.setMessage("Profile updated successfully!");

                alertDialog.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener()
                        {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {


                            }
                        });

                alertDialog.setCancelable(true);
                AlertDialog alert = alertDialog.create();
                alert.show();

                Button positiveBtn = alert.getButton(AlertDialog.BUTTON_POSITIVE);
                positiveBtn.setTextColor(Color.parseColor("#E91E63"));


                break;

            case R.id.button_signout:


                AlertDialog.Builder alertDialog1 = new AlertDialog.Builder(
                        getActivity());
                alertDialog1.setTitle("Confirmation");
                alertDialog1.setMessage("Do you want to sign out?");

                alertDialog1.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener()
                        {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {


                            }
                        });

                alertDialog1.setPositiveButton("Sign out",
                        new DialogInterface.OnClickListener()
                        {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {

                                Intent objIntent = new Intent(profileFragment.this.getActivity(),activitySignup.class );
                                startActivity(objIntent);

                            }
                        });

                alertDialog1.setCancelable(true);
                AlertDialog alert1 = alertDialog1.create();
                alert1.show();

                Button positiveBtn1 = alert1.getButton(AlertDialog.BUTTON_POSITIVE);
                positiveBtn1.setTextColor(Color.parseColor("#E91E63"));

                Button NagativeBtn1 = alert1.getButton(AlertDialog.BUTTON_NEGATIVE);
                NagativeBtn1.setTextColor(Color.parseColor("#E91E63"));

                break;
        }
    }
}