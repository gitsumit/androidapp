package com.example.foc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class homeFragment extends Fragment {


    String email, pwd;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.home_fragment_layout, null);


        ImageView longClick = (ImageView) view.findViewById(R.id.rest1);


        longClick.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                builder.setTitle("Restaurant");
                builder.setMessage("Address:401 Queen Street, Auckland 1042");

                builder.setPositiveButton("OK", null);
                AlertDialog dialog = builder.create();
                dialog.show();

                Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                positiveBtn.setTextColor(Color.parseColor("#E91E63"));

                return true;
            }
        });
        return view;

//        TextView btn = view.findViewById(R.id.gotores);
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(getActivity(), menucart.class);
//                startActivity(i);
//                ((Activity) getActivity()).overridePendingTransition(0, 0);
//            }
//        });
//        return view;

    }

//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        image = (ImageView) findViewById(R.id.imageView1);
//        image.setOnLongClickListener(new OnLongClickListener() {
//
//            @Override
//            public boolean onLongClick(View v) {
//                Intent intent = new Intent(Intent.ACTION_PICK);
//                intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
//                startActivityForResult(intent, PICK_FROM_ALBUM);
//                return false;
//            }
//        });
//    }

    public void gotoCart(View view)
    {
        Intent i = new Intent(getActivity(), menucart.class);
        startActivity(i);
        ((Activity) getActivity()).overridePendingTransition(0, 0);
    }



//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        Toast.makeText(homeFragment.this.getActivity(),"FoodonCampus destroyed",Toast.LENGTH_LONG).show();
//
//    }
}
