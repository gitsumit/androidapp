package com.example.foc;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activitySignup extends AppCompatActivity{


    EditText objEmail,objPwd,objUsername;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        objUsername = (EditText)findViewById(R.id.txtusername);
        objEmail   = (EditText)findViewById(R.id.txtemail);
        objPwd   = (EditText)findViewById(R.id.txtpwd);

    }

    public void doSignIn(View v)
    {
        Intent objIntent = new Intent(this, activitySignIn.class);
        startActivity(objIntent);
    }

    public void doActivityHome(View v)
    {
        if (objUsername.getText().toString().trim().equals("") || objEmail.getText().toString().trim().equals("") || objPwd.getText().toString().trim().equals(""))
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Alert! All fields are required to register account");

            builder.setPositiveButton("OK", null);
            AlertDialog dialog = builder.create();
            dialog.show();

            Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveBtn.setTextColor(Color.parseColor("#E91E63"));

        }
        else
        {
            Log.e("Email value",  objEmail.getText().toString());
            Log.e("Pass value", objPwd.getText().toString());

            SharedPreferences.Editor editor = getSharedPreferences("credentials", MODE_PRIVATE).edit();

            editor.putString("email", objEmail.getText().toString());
            editor.putString("password", objPwd.getText().toString());
            editor.commit();


            AlertDialog.Builder alertDialog1 = new AlertDialog.Builder(
                    this);
            alertDialog1.setTitle("Confirmation");
            alertDialog1.setMessage("Great ! Account is Registered.");

            alertDialog1.setNegativeButton("Cancel",
                    new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog,
                                            int which) {
                        }
                    });

            alertDialog1
                    .setPositiveButton("Login", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                            Intent move = new Intent(activitySignup.this, activitySignIn.class);
                            startActivity(move);

                        }
                    });

            AlertDialog alert1 = alertDialog1.create();
            alert1.show();

            Button positiveBtn1 = alert1.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveBtn1.setTextColor(Color.parseColor("#E91E63"));

            Button NagativeBtn1 = alert1.getButton(AlertDialog.BUTTON_NEGATIVE);
            NagativeBtn1.setTextColor(Color.parseColor("#E91E63"));


        }

    }
}
