package com.example.foc;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.PublicKey;

public class activitySignIn extends AppCompatActivity {

    String email,pwd;
    EditText objEmail, objPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);


        objEmail   = (EditText)findViewById(R.id.signuseremail);
        objPwd   = (EditText)findViewById(R.id.signuserpassword);

        SharedPreferences prefs = getSharedPreferences("credentials", MODE_PRIVATE);
        String emailValue = prefs.getString("email", null);
        String passValue = prefs.getString("password", null);


        if (emailValue != null || passValue != null)
        {
                Log.e("success", "success");

                email = prefs.getString("email", "No name defined");//"No name defined" is the default value.
                pwd = prefs.getString("password", "No name defined"); //0 is the default value.
        }
        else
            {

            Log.e("failure", "no email and passwords");
        }

    }


    @Override
    public void onStart() {
        super.onStart();
//        Toast.makeText(this,"FoodonCampus Started",Toast.LENGTH_LONG).show();

    }

    public void doSignUp(View v)
    {
        Intent objIntent = new Intent(this, activitySignup.class);
        startActivity(objIntent);
    }

    public void doForgotPassword(View v)
    {
        Intent objIntent = new Intent(this, activityForgotPwd.class);
        startActivity(objIntent);
    }

    public void doSignIn(View v)
    {

        if (objEmail.getText().toString().trim().equals("") || objPwd.getText().toString().trim().equals(""))
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Alert! Both fields are required to login");

            builder.setPositiveButton("OK", null);
            AlertDialog dialog = builder.create();
            dialog.show();

            Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveBtn.setTextColor(Color.parseColor("#E91E63"));

        }
        else
        {
            if (objEmail.getText().toString().equals(email) && (objPwd.getText().toString().equals(pwd)))
            {
                Intent objIntent = new Intent(this, activityHome.class);
                startActivity(objIntent);
            }
            else
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setMessage("Failure! Wrong credentials");

                builder.setPositiveButton("OK", null);
                AlertDialog dialog = builder.create();
                dialog.show();

                Button positiveBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                positiveBtn.setTextColor(Color.parseColor("#E91E63"));

            }

        }

    }

}
